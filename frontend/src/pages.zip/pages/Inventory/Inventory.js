import React from 'react'

function Inventory() {
  return (
    <div>
      <h1>Inventory</h1>
    </div>
  )
}

export default Inventory